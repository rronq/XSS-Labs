<!DOCTYPE html>
<html>
<head>
    <title>Processed Input</title>
</head>
<body>
    <?php
    // Check if the form has been submitted and if the input field is not empty
    if (isset($_POST['user_input']) && !empty($_POST['user_input'])) {
        $user_input = $_POST['user_input'];
        echo "<p>You typed: $user_input</p>";
    } else {
        echo "<p>No input provided. Please go back and enter something.</p>";
    }
    ?>
</body>
</html>